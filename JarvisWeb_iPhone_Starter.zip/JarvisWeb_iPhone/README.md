# JARVIS Mobile Web Starter

A mobile-first web app prototype designed for Safari on iPhone 13 Pro Max.

## What works locally
- Responsive Jarvis-style interface with Chat, Studio, Memory, and Settings tabs.
- Chat UI with clearly labeled local demo responses (not a real AI model).
- Image/video prompt preparation UI (does not generate media).
- Local notes stored in browser localStorage, with export/delete controls.
- Browser speech input where supported, and text-to-speech where supported.
- PWA manifest and icon.

## Not yet connected
- AI model / ChatGPT-style responses.
- Real image or video generation.
- Secure server/backend, accounts, cloud sync.
- Full camera workflow, Siri-level device control, phone calls, or unrestricted system access.

## Open on iPhone
This is a static web app. To use it reliably as a Home Screen web app, publish the contents of this folder to an HTTPS static host, then open the hosted URL in Safari and choose Share > Add to Home Screen. A file opened directly from Files may not support all PWA features.

## Suggested hosting
A Git repository with GitHub Pages or another HTTPS static hosting provider. Hosting instructions may change; use the host's current setup guide.

## Security
Never put provider API keys in `index.html` or other browser code. Real AI and media providers must be called through a secure backend that protects credentials, enforces limits, and handles errors.

## Status
Source files created. Not yet hosted on a public HTTPS URL, connected to an AI/media provider, or tested on a physical iPhone.
