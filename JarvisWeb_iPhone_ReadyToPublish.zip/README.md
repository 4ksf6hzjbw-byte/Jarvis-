# JARVIS Mobile Web Starter

A mobile-first web app prototype designed for Safari on iPhone 13 Pro Max.

## Included
- Jarvis-inspired responsive interface with Chat, Studio, Memory, and Settings.
- Local demo responses that clearly disclose there is no connected AI model.
- Image/video prompt preparation UI; no media is generated without a provider.
- Local notes with export/delete controls.
- Browser speech input where supported, and text-to-speech where supported.
- PWA manifest, iPhone home-screen icon, and service-worker cache for core files.

## Publish from iPhone
Read `DEPLOY_FROM_IPHONE.md`. It describes publishing these static files with GitHub Pages using Safari only. The repository must have `index.html` at its root. GitHub Pages on a free account requires a public repository, so treat all source files as public.

## Security
Never put provider API keys in browser code. Real AI/media services must be called through a secure backend that protects credentials, enforces usage limits, and handles errors.

## Not yet connected
- AI model / ChatGPT-style responses.
- Real image or video generation.
- Secure server/backend, account system, cloud sync.
- Full camera workflow, Siri-level device control, phone calls, or unrestricted system access.

## Status
Source created and deployment instructions included. Not yet hosted at a public HTTPS URL or tested on a physical iPhone.
