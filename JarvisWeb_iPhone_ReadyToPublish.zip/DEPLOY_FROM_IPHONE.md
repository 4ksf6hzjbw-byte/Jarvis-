# Publish JARVIS from an iPhone (no Mac or PC)

This package is a static website. It can be hosted on GitHub Pages for free, but publishing requires you to sign in to your own GitHub account and authorize the repository.

## Before you begin
- Do not put passwords, API keys, personal information, or private notes in this repository.
- GitHub Pages content is public on GitHub Free, so treat everything in this site source as public.
- This starter has no connected AI provider. It does not generate real images/videos yet.

## Steps in Safari
1. Open https://github.com and sign in or create an account, if you are eligible to do so.
2. Create a new repository named `jarvis-mobile`. For the simplest GitHub Pages path on a free account, set it to **Public**. Do not select any license or add other files if you prefer to keep this package's files clean.
3. Download and extract the Jarvis Web Starter ZIP in the iPhone Files app.
4. In the new repository, choose **Add file → Upload files**. Select the extracted site files (not the ZIP itself). Upload `index.html`, `manifest.webmanifest`, `icon.svg`, `apple-touch-icon.png`, `service-worker.js`, `.nojekyll`, `README.md`, `STATUS.json`, and `DEPLOY_FROM_IPHONE.md`. If iOS does not let you select all files at once, upload them in smaller groups. Keep `index.html` at the repository root.
5. Commit the upload to the `main` branch.
6. In the repository, open **Settings → Pages**.
7. Under **Build and deployment**, choose **Deploy from a branch**, select branch `main`, folder `/(root)`, then tap **Save**.
8. Wait for GitHub Pages to publish the site. Under Settings → Pages, tap **Visit site**. The URL will resemble `https://YOUR-USERNAME.github.io/jarvis-mobile/`.
9. Open the site URL in Safari. Tap **Share → Add to Home Screen**. If offered, enable **Open as Web App**, then tap **Add**.

Official references:
- Upload files: https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
- Configure Pages: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
- Create a Pages site: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Current feature status
- UI, local demo chat, local notes, note export/delete, generation-request preparation, speech input where browser-supported, and text-to-speech where supported: implemented in source.
- Real AI responses, real image generation, real video generation, secure backend, account sync, and iOS-native integrations: not connected.
- The service worker caches core files for basic offline opening after a successful first load. Network-dependent AI features cannot work offline.
